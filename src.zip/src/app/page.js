"use client";
import { useRouter } from "next/navigation";

export default function InstructionScreen() {
  const router = useRouter();

  const startTest = () => {
    router.push("/check-permissions");
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-blue-500 to-purple-500 text-white">
      <div className="bg-white p-8 rounded-lg shadow-lg text-center">
        <h1 className="text-4xl font-extrabold text-gray-800 mb-4">
          AI Interview Platform
        </h1>
        <p className="text-lg text-gray-600 mb-6">
          Prepare for your AI interview. Read the instructions carefully and
          proceed to the test.
        </p>
        <button
          onClick={startTest}
          className="px-8 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-all"
        >
          Start Test
        </button>
      </div>
    </div>
  );
}
