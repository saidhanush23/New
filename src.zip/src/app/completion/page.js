export default function CompletionScreen() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-green-400 to-blue-400 text-white">
      <div className="bg-white p-8 rounded-lg shadow-lg text-center">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          Test Completed
        </h1>
        <p className="text-lg text-gray-600">
          Thank you for participating in the AI interview!
        </p>
      </div>
    </div>
  );
}
