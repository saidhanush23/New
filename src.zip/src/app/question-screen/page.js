"use client";

import React from "react";
import "./styles.css";

export default function QuestionScreen() {
  const sendQuestionData = async () => {
    const response = await fetch("/api/start-recording", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        question: "What is your name?",
        status: "active",
      }),
    });

    const result = await response.json();
    console.log(result); // { message: "Recording started" }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
      <div className="bg-white p-8 rounded-lg shadow-lg text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">Question 1</h1>
        <p className="text-gray-600 mb-6">
          Listen to the question and prepare your answer.
        </p>
        <audio
          controls
          className="mb-6 w-full max-w-lg"
          src="/question-audio.mp3"
        ></audio>
        <button
          onClick={sendQuestionData}
          className="px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-all"
        >
          Send Question Data
        </button>
      </div>
    </div>
  );
}
