// src/app/api/start-recording/route.js

export async function POST(req) {
  try {
    const { question, status } = await req.json();

    console.log("Received question data:", question, "Status:", status);

    return new Response(JSON.stringify({ message: "Recording started" }), {
      status: 200,
    });
  } catch (error) {
    console.error("Error processing API request:", error);
    return new Response(
      JSON.stringify({ message: "Failed to start recording" }),
      {
        status: 500,
      }
    );
  }
}
