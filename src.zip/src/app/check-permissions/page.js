"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function CheckPermissions() {
  const router = useRouter();
  const [permissionsGranted, setPermissionsGranted] = useState(false);

  const checkPermissions = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      await navigator.mediaDevices.getDisplayMedia({ video: true });
      setPermissionsGranted(true);
    } catch (error) {
      console.error("Permissions denied", error);
      setPermissionsGranted(false);
    }
  };

  const proceed = () => {
    if (permissionsGranted) router.push("/question");
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-green-400 to-blue-400 text-white">
      <div className="bg-white p-6 rounded-lg shadow-lg text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">
          Check Permissions
        </h1>
        <p className="text-gray-600 mb-6">
          Grant permissions to proceed with the test.
        </p>
        <button
          onClick={checkPermissions}
          className="px-6 py-3 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 mb-4 transition-all"
        >
          Grant Permissions
        </button>
        {permissionsGranted ? (
          <button
            onClick={proceed}
            className="px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-all"
          >
            Proceed to Test
          </button>
        ) : (
          <p className="text-red-500">Permissions not granted</p>
        )}
      </div>
    </div>
  );
}
